#!/usr/bin/env bash

full_qualified_name=${1}

mvn eu.stamp-project:dspot-maven:amplify-unit-tests \
    -Dpath-pit-result=mutations.xml \
    -Diteration=1 \
    -Damplifiers=MethodAdd,MethodRemove \
    -Dtest=${full_qualified_name}