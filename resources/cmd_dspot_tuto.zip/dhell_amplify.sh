#!/usr/bin/env bash

mvn eu.stamp-project:dspot-maven:amplify-unit-tests \
    -DtargetOneTestClass \
    -Dtest=eu.stamp_project.examples.dhell.HelloAppTest