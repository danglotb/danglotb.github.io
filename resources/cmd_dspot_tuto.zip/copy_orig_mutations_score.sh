#!/usr/bin/env bash

cp target/pit-reports/*/mutations.xml ./mutations.xml