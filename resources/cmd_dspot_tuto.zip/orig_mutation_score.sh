#!/usr/bin/env bash

full_qualified_name=${1}

mvn clean test -DskipTests \
    eu.stamp-project:pitmp-maven-plugin:descartes \
    -DoutputFormats=XML \
    -DtargetTests=${full_qualified_name}