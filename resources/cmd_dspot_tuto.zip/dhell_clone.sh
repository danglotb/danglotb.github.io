#!/usr/bin/env bash

git clone https://github.com/STAMP-project/dhell.git
