#!/usr/bin/env bash

full_qualified_name=${1}

mvn eu.stamp-project:dspot-maven:amplify-unit-tests \
    -Dpath-pit-result=mutations.xml \
    -Dtest=${full_qualified_name}